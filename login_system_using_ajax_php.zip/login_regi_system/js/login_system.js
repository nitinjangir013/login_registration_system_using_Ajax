$(document).ready(function(){
  $(".card_loader").hide();

  $(document).on("click",".reg_form_open_btn span",function(){
    $("#login_form").hide();
    $("#registration_form").show();
  });

  $(document).on("click",".login_form_open_btn span",function(){
    $("#login_form").show();
    $("#registration_form").hide();
  });


  // Show Hide Password
  $(document).on("click",".showpassword",function() {
    if($(this).parent().children("input").attr('type') == 'password')
    {
      $(this).parent().children("input").attr('type','text');
      $(this).html("<i class='fa-solid fa-eye-slash'></i>");
    }
    else if($(this).parent().children("input").attr('type') == 'text')
    {
      $(this).parent().children("input").attr('type','password');
      $(this).html("<i class='fa-solid fa-eye'></i>");
    }
  });

  $('#login_form').submit(function(event) {
    event.preventDefault();

    var loginpassword = $('#loginpassword').val();

    if(loginpassword.length<6)
    {
      $('#login_error_msg').text("Your password length is less than 6").css({"color": "brown"});
    }
    else
    {
      $('#login_error_msg').text("Please Wait...").css({"color": "green"});
      var formData = $(this).serialize();
      $.ajax({
          type: "POST",
          url: "./parts/login_data_setup.php",
          data: formData,
          success: function(response) {
            $('#login_form')[0].reset();
            if(response == 1)
            {
              $('#login_error_msg').text("Login Sucessfully.").css({"color": "green"})
            }
            else
            {
              $('#login_error_msg').text(response).css({"color": "brown"});
            }
          },
          error: function(xhr, status, error) {
            console.error("Error:", error);
          }
      });
    }
  });


  $('#registration_form').submit(function(event) {
    event.preventDefault();

    var password = $('#password').val();
    var confirmPassword = $('#confirmpassword').val();

    if(password.length<6)
    {
      $('#reg_error_msg').text("Your password length is less than 6").css({"color": "brown"});
    }
    else
    {
      if (password !== confirmPassword)
      {
        $('#reg_error_msg').text("Passwords do not match").css({"color": "brown"});
      }
      else {
        $('#reg_error_msg').text("Please Wait...").css({"color": "green"});
        var formData = $(this).serialize();
        $.ajax({
            type: "POST",
            url: "./parts/login_data_setup.php",
            data: formData,
            success: function(response) {
              $('#registration_form')[0].reset();
              $('#reg_error_msg').text(response).css({"color": "green"});
            },
            error: function(xhr, status, error) {
              console.error("Error:", error);
            }
        });
      }
    }
  });


  // Forgot
  var isotpvalue = 0;
  $('#forgot_password_form').submit(function(event) {
    event.preventDefault();
    $("#forgot_password_form").hide();
    $("#otp_form").show();
    $('#forgot_error_msg').text("Sent OTP").css({"color": "green"});
    var formData = $(this).serialize();
    $.ajax({
        type: "POST",
        url: "./parts/login_data_setup.php",
        data: formData,
        success: function(response) {
          // $('#forgot_error_msg').text(response).css({"color": "green"});
          if(response != 0)
          {
            isotpvalue = response;
            $("#otphiddeninput").val(isotpvalue);
          }
        },
        error: function(xhr, status, error) {
          console.error("Error:", error);
        }
    });
  });

  $('#resend_otp').on("click",function(event) {
    $('#otp_error_msg').text("Resent OTP").css({"color": "green"});
    var data = "forgotemailid="+$("#forgotemailid").val();
    $.ajax({
        type: "POST",
        url: "./parts/login_data_setup.php",
        data: data,
        success: function(response) {
          // $('#otp_error_msg').text(response).css({"color": "green"});
          if(response != 0)
          {
            isotpvalue = response;
            $("#otphiddeninput").val(isotpvalue);
          }
        },
        error: function(xhr, status, error) {
          console.error("Error:", error);
        }
    });
  });

  $('#otp_form').submit(function(event) {
    event.preventDefault();
    var otpemailid = $("#otpemailid").val();
    if(otpemailid == isotpvalue)
    {
      $("#otp_error_msg").text("Valid OTP").css({"color": "green"});
      $("#otp_form").hide();
      $("#password_change_form").show();
    }
    else
    {
      $("#otp_error_msg").text("Invalid OTP, please try again.").css({"color": "brown"});
    }
  });

  $('#password_change_form').submit(function(event) {
    event.preventDefault();
    var password = $('#changepassword').val();
    var confirmPassword = $('#changeconfirmpassword').val();

    if(password.length<6)
    {
      $('#change_pass_error_msg').text("Your password length is less than 6").css({"color": "brown"});
    }
    else
    {
      if (password !== confirmPassword)
      {
        $('#change_pass_error_msg').text("Passwords do not match").css({"color": "brown"});
      }
      else {
        $('#change_pass_error_msg').text("Please Wait...").css({"color": "green"});
        var formData = $(this).serialize()+"&emailidpasschange="+$("#forgotemailid").val();
        $.ajax({
            type: "POST",
            url: "./parts/login_data_setup.php",
            data: formData,
            success: function(response) {
              $('#password_change_form')[0].reset();
              $('#change_pass_error_msg').text(response).css({"color": "green"});
            },
            error: function(xhr, status, error) {
              console.error("Error:", error);
            }
        });
      }
    }
  });



});