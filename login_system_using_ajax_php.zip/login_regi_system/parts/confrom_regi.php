<?php
  session_start();
  include '../helper/db_connection.php';

  $sql = "SELECT * FROM `user_info` WHERE `email`='".$_GET['email']."' AND `code`=".$_GET['uncode']." AND `forgot_link_uniqe`='".$_GET['code']."'";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      $sql = "UPDATE `user_info` SET `code`='', `forgot_link_uniqe`='', `verify`=1 WHERE id=".$row['id'];

      if ($conn->query($sql) === TRUE) {
        echo "Registration successfull";
        header("location: ../login_regi.html");
      } else {
        echo "Error updating record: " . $conn->error;
      }
    }
  } else {
    echo "Already Registration";
    header("location: ../login_regi.html");
  }


  $conn->close();
?>