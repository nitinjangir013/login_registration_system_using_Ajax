<?php
  session_start();
  include '../helper/db_connection.php';

// Mailer
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;
  require '../phpmailer/src/Exception.php';
  require '../phpmailer/src/PHPMailer.php';
  require '../phpmailer/src/SMTP.php';
  $mail = new PHPMailer(true);
  $mail->isSMTP();
  $mail->Host = '';
  $mail->SMTPAuth = true;
  $mail->Username = '';
  $mail->Password = '';
  $mail->SMTPSecure = 'ssl';
  $mail->Port = 465;

  function generateUniqueText($length) {
    $uniqueText = uniqid('', true);
    $uniqueText = str_replace(".", "", $uniqueText); // Remove dots to ensure 12 characters
    return substr($uniqueText, 0, $length);
  }
  $uniqueText = generateUniqueText(26);

  function generateUniqueNumber($length) {
    $characters = '0123456789';
    $characterLength = strlen($characters);
    $uniqueNumber = '';

    for ($i = 0; $i < $length; $i++) {
        $randomIndex = rand(0, $characterLength - 1);
        $uniqueNumber .= $characters[$randomIndex];
    }

    return $uniqueNumber;
  }

  $uniqueNumber = generateUniqueNumber(6);
  

  // Log In
  if(isset($_POST['loginemailid']))
  {
    $sql = "SELECT * FROM `user_info` WHERE `email`='".$_POST['loginemailid']."' AND `password`=md5('".$_POST['password']."')";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      // output data of each row
      while($row = $result->fetch_assoc()) {
        if ($row["verify"] == 1) {
          echo 1;
        }
        else
        {
          echo "Account verification pending, please complete the process.";
        }
      }
    } else {
      echo 'Incorrect Email or Password.';
    }
  }


  // Register
  if(isset($_POST['emailid']))
  {

    $sql = "SELECT * FROM `user_info` WHERE `phone`='".$_POST['phoneno']."' OR `email`='".$_POST['emailid']."'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      // output data of each row
      while($row = $result->fetch_assoc()) {
        echo "Your account is already accessible.";
      }
    } else {
      $mail->setFrom($_POST['emailid'],"Nitin Jangir");
      $mail->addAddress($_POST['emailid']);
      $mail->isHTML(true);
      $mail->Subject = 'Registration';
    
      $fname = mysqli_real_escape_string($conn, $_POST['fname']);
      $lname = mysqli_real_escape_string($conn, $_POST['lname']);
      $phoneno = mysqli_real_escape_string($conn, $_POST['phoneno']);
      $emailid = mysqli_real_escape_string($conn, $_POST['emailid']);
      $password = mysqli_real_escape_string($conn, $_POST['password']);
      $sql = "INSERT INTO `user_info`(`fname`, `lname`, `phone`, `email`, `password`, `forgot_link_uniqe`, `code`) VALUES ('$fname','$lname','$phoneno','$emailid',md5('$password'),'$uniqueText', '$uniqueNumber')";
      if ($conn->query($sql) === TRUE) {
        echo "Please verify your email to complete the registration process.";
        $mail->Body = '<!DOCTYPE html>
        <html>
        <head>

          <meta charset="utf-8">
          <meta http-equiv="x-ua-compatible" content="ie=edge">
          <title>Email Confirmation</title>
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <style type="text/css">
          /**
           * Google webfonts. Recommended to include the .woff version for cross-client compatibility.
           */
          @media screen {
            @font-face {
              font-family: `Source Sans Pro`;
              font-style: normal;
              font-weight: 400;
              src: local(`Source Sans Pro Regular`), local(`SourceSansPro-Regular`), url(https://fonts.gstatic.com/s/sourcesanspro/v10/ODelI1aHBYDBqgeIAH2zlBM0YzuT7MdOe03otPbuUS0.woff) format(`woff`);
            }
            @font-face {
              font-family: `Source Sans Pro`;
              font-style: normal;
              font-weight: 700;
              src: local(`Source Sans Pro Bold`), local(`SourceSansPro-Bold`), url(https://fonts.gstatic.com/s/sourcesanspro/v10/toadOcfmlt9b38dHJxOBGFkQc6VGVFSmCnC_l7QZG60.woff) format(`woff`);
            }
          }
          /**
           * Avoid browser level font resizing.
           * 1. Windows Mobile
           * 2. iOS / OSX
           */
          body,
          table,
          td,
          a {
            -ms-text-size-adjust: 100%; /* 1 */
            -webkit-text-size-adjust: 100%; /* 2 */
          }
          /**
           * Remove extra space added to tables and cells in Outlook.
           */
          table,
          td {
            mso-table-rspace: 0pt;
            mso-table-lspace: 0pt;
          }
          /**
           * Better fluid images in Internet Explorer.
           */
          img {
            -ms-interpolation-mode: bicubic;
          }
          /**
           * Remove blue links for iOS devices.
           */
          a[x-apple-data-detectors] {
            font-family: inherit !important;
            font-size: inherit !important;
            font-weight: inherit !important;
            line-height: inherit !important;
            color: inherit !important;
            text-decoration: none !important;
          }
          /**
           * Fix centering issues in Android 4.4.
           */
          div[style*="margin: 16px 0;"] {
            margin: 0 !important;
          }
          body {
            width: 100% !important;
            height: 100% !important;
            padding: 0 !important;
            margin: 0 !important;
          }
          /**
           * Collapse table borders to avoid space between cells.
           */
          table {
            border-collapse: collapse !important;
          }
          a {
            color: #1a82e2;
          }
          img {
            height: auto;
            line-height: 100%;
            text-decoration: none;
            border: 0;
            outline: none;
          }
          </style>

        </head>
        <body style="background-color: #e9ecef;">

          <!-- start preheader -->
          <div class="preheader" style="display: none; max-width: 0; max-height: 0; overflow: hidden; font-size: 1px; line-height: 1px; color: #fff; opacity: 0;">
            A preheader is the short summary text that follows the subject line when an email is viewed in the inbox.
          </div>
          <!-- end preheader -->

          <!-- start body -->
          <table border="0" cellpadding="0" cellspacing="0" width="100%">

            <!-- start logo -->
            <tr>
              <td align="center" bgcolor="#e9ecef">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">
                  <tr>
                    <td align="center" valign="top" style="padding: 36px 24px;">
                      <a href="https://www.blogdesire.com" target="_blank" style="display: inline-block;">
                        <img src="https://www.blogdesire.com/wp-content/uploads/2019/07/blogdesire-1.png" alt="Logo" border="0" width="48" style="display: block; width: 48px; max-width: 48px; min-width: 48px;">
                      </a>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- end logo -->

            <!-- start hero -->
            <tr>
              <td align="center" bgcolor="#e9ecef">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">
                  <tr>
                    <td align="left" bgcolor="#ffffff" style="padding: 36px 24px 0; font-family: `Source Sans Pro`, Helvetica, Arial, sans-serif; border-top: 3px solid #d4dadf;">
                      <h1 style="margin: 0; font-size: 32px; font-weight: 700; letter-spacing: -1px; line-height: 48px;">Confirm Your Email Address</h1>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- end hero -->

            <!-- start copy block -->
            <tr>
              <td align="center" bgcolor="#e9ecef">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">

                    <!-- start button -->
                  <tr>
                    <td align="left" bgcolor="#ffffff">
                      <table border="0" cellpadding="0" cellspacing="0" width="100%">
                        <tr>
                          <td align="center" bgcolor="#ffffff" style="padding: 12px;">
                            <table border="0" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" bgcolor="#1a82e2" style="border-radius: 6px;">
                                  <a href="http://localhost/login_regi_system/parts/confrom_regi.php?code='.$uniqueText.'&email='.$emailid.'&uncode='.$uniqueNumber.'" target="_blank" style="display: inline-block; padding: 16px 36px; font-family: `Source Sans Pro`, Helvetica, Arial, sans-serif; font-size: 16px; color: #ffffff; text-decoration: none; border-radius: 6px;">Confirm</a>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <!-- end button -->

                  <!-- start copy -->
                  <tr>
                    <td align="left" bgcolor="#ffffff" style="padding: 24px; font-family: `Source Sans Pro`, Helvetica, Arial, sans-serif; font-size: 16px; line-height: 24px; border-bottom: 3px solid #d4dadf">
                      <p style="margin: 0;">Cheers,<br> Paste</p>
                    </td>
                  </tr>
                  <!-- end copy -->

                </table>
              </td>
            </tr>
            <!-- end copy block -->
          </table>
          <!-- end body -->

        </body>
        </html>';
        $mail->send();
      } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }
    }
  }


  // Forgot
  if(isset($_POST['forgotemailid']))
  {
    $forgotemailid = mysqli_real_escape_string($conn, $_POST['forgotemailid']);
    $mail->setFrom($forgotemailid);
    $mail->addAddress($forgotemailid);
    $mail->isHTML(true);
    $mail->Subject = 'Forgot Password';
    $mail->Body = 'OTP : '.$uniqueNumber;
    $mail->send();
    $sql = "UPDATE `user_info` SET `forgot_link_uniqe`='$uniqueText', `code`='$uniqueNumber' WHERE `email`='".$forgotemailid."'";
    if ($conn->query($sql) === TRUE) {
      echo $uniqueNumber;
    } else {
      echo 0;
    }
  }

  // Forgot
  if(isset($_POST['changepassword']))
  {
    $changepassword = mysqli_real_escape_string($conn, $_POST['changepassword']);
    $emailid = mysqli_real_escape_string($conn, $_POST['emailidpasschange']);
    $sql = "UPDATE `user_info` SET `password`=md5('$changepassword'), `code`='', `forgot_link_uniqe`='', `verify`=1 WHERE `email`='".$emailid."' AND `code`='".$_POST['otp_code']."'";
    if ($conn->query($sql) === TRUE) {
      echo "Password updated successfully.";
    } else {
      echo 0;
    }
  }

  $conn->close();
?>